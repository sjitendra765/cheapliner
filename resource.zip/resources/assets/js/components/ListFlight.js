import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import NavBar from './NavBar';
import TabPanes from './TabPanes'
import { connect } from 'react-redux'

class ListFlight extends Component {
       constructor(props) {
    super(props);
    this.state={
      list: [{
        'from': "ktm",
        'to':'pokhara',
        'amount':480,
        'Date': '2018-09-09'
      },
      {
        'from': "ktm",
        'to':'pokhara',
        'amount':477,
        'Date': '2018-09-09'
      }]
    }
}

 


    render() {
      console.log(this.state.list)
      //var list = this.state.list;
      function isAutobot(list) {
        console.log(list)
  return list.from === "ktm";
}
      function isSortBy(li){
          return li.sort((a,b) =>{
            return a.amount- b.amount
          })
      }
      var autobots = this.state.list.filter(isAutobot);
      var sortbypayment = isSortBy(this.state.list)
    	console.log(autobots)
      console.log(sortbypayment)
        return (
<div className="fh5co-hero">
 <div className="container">

  <div className="row" style={{}}>
      <div className="col-md-2">
        
      </div>
      <div className="col-md-10">
      <div className="card">
          <div className="card-header">
            <strong>Turkish Airlines</strong>
             <strong className="float-right" style={{fontSize: 24}}>85€</strong>
          </div>

        <div className="card-body">
          <div className="row">
          <div className="col-md-4">
            <h5 className="card-title"><img src="images/TK.png" /></h5>
          </div>
          <div className="col-md-4">
             <p className="card-text"><strong>06:30 - 12:30</strong></p>
          </div>
          <div className="col-md-4" style={{marginBottom: 30}}>
            <p className="card-title"><strong>4 hours</strong></p>
            <p className="card-title"><strong>1 Stop at SAW</strong></p>
          </div>
        </div>
          <div className="row">
          <div className="col-md-4">
            <h5 className="card-title"><img src="images/TK.png" /></h5>
          </div>
          <div className="col-md-4">
             <p><strong>20:30 - 23:30</strong></p>
          </div>
          <div className="col-md-4">
            <p className="card-title"><strong>3:30 hours</strong></p>
            <p className="card-title"><strong>Direct flight</strong></p>
          </div>
        </div>
      </div>
      <div className="card-footer text-muted">
          <a href="#" className="btn btn-primary float-right">Buy now</a>
      </div>
    </div>
    </div>
  </div>

    <div className="row" style={{}}>
      <div className="col-md-10">
      <div className="card">
          <div className="card-header">
            <strong>Turkish Airlines</strong>
             <strong className="float-right" style={{fontSize: 24}}>85€</strong>
          </div>

        <div className="card-body">
          <div className="row">
          <div className="col-md-4">
            <h5 className="card-title"><img src="images/TK.png" /></h5>
          </div>
          <div className="col-md-4">
             <p className="card-text"><strong>06:30 - 12:30</strong></p>
          </div>
          <div className="col-md-4" style={{marginBottom: 30}}>
            <p className="card-title"><strong>4 hours</strong></p>
            <p className="card-title"><strong>1 Stop at SAW</strong></p>
          </div>
        </div>
          <div className="row">
          <div className="col-md-4">
            <h5 className="card-title"><img src="images/TK.png" /></h5>
          </div>
          <div className="col-md-4">
             <p><strong>20:30 - 23:30</strong></p>
          </div>
          <div className="col-md-4">
            <p className="card-title"><strong>3:30 hours</strong></p>
            <p className="card-title"><strong>Direct flight</strong></p>
          </div>
        </div>
      </div>
      <div className="card-footer text-muted">
          <a href="#" className="btn btn-primary float-right">Buy now</a>
      </div>
    </div>
    </div>
  </div>


  </div>
</div>
        );
    }
}
const mapStateToProps = (state, ownProps) =>{
  console.log(state.flightReducer[0][8])
    return {
        flights: state.flight
    }
} 

const mapDsipatchToProps = (dispatch) =>{
    return {
       
    }
}


export default connect(mapStateToProps,mapDsipatchToProps)(ListFlight);




